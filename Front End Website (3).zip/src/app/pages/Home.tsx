import { Link } from 'react-router';
import { WebinarCard } from '../components/WebinarCard';
import { mockWebinars } from '../lib/mockData';
import { Button } from '../components/ui/button';
import { ArrowRight, BookOpen, Calendar, Users, Video } from 'lucide-react';

export default function Home() {
  const upcomingWebinars = mockWebinars.filter(w => w.status === 'upcoming').slice(0, 3);
  const liveWebinars = mockWebinars.filter(w => w.status === 'live');

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-indigo-700 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-5xl font-bold mb-6">
              Transform Your Skills with Expert-Led Webinars
            </h1>
            <p className="text-xl mb-8 text-blue-100">
              Join thousands of learners in live interactive workshops and webinars. 
              Learn from industry experts, access recordings, and grow your career.
            </p>
            <div className="flex gap-4">
              <Link to="/webinars">
                <Button size="lg" variant="secondary">
                  Browse Webinars
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white/10">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Live Webinars Section */}
      {liveWebinars.length > 0 && (
        <section className="py-12 bg-red-50">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold mb-2">🔴 Live Now</h2>
                <p className="text-gray-600">Join these sessions happening right now</p>
              </div>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {liveWebinars.map(webinar => (
                <WebinarCard key={webinar.id} webinar={webinar} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Upcoming Webinars Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Upcoming Webinars</h2>
              <p className="text-gray-600">Register for these upcoming sessions</p>
            </div>
            <Link to="/webinars">
              <Button variant="outline">
                View All
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingWebinars.map(webinar => (
              <WebinarCard key={webinar.id} webinar={webinar} />
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose EduWebinar?</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Video className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Live Streaming</h3>
              <p className="text-sm text-gray-600">
                Interactive live sessions with real-time Q&A
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Access Resources</h3>
              <p className="text-sm text-gray-600">
                Download materials and watch recordings anytime
              </p>
            </div>

            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Expert Instructors</h3>
              <p className="text-sm text-gray-600">
                Learn from industry professionals and leaders
              </p>
            </div>

            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="font-semibold mb-2">Easy Registration</h3>
              <p className="text-sm text-gray-600">
                Quick sign-up process and calendar integration
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
