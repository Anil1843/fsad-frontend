import { useState } from 'react';
import { mockWebinars, mockRegistrations } from '../lib/mockData';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Calendar, Plus, Users, Video, FileText, Trash2, Edit } from 'lucide-react';
import { toast } from 'sonner';

export default function Admin() {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newWebinar, setNewWebinar] = useState({
    title: '',
    description: '',
    instructor: '',
    date: '',
    time: '',
    duration: '',
    category: '',
    maxParticipants: 50,
  });

  const handleCreateWebinar = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Webinar created successfully!');
    setShowCreateForm(false);
    setNewWebinar({
      title: '',
      description: '',
      instructor: '',
      date: '',
      time: '',
      duration: '',
      category: '',
      maxParticipants: 50,
    });
  };

  const handleDeleteWebinar = (title: string) => {
    toast.success(`Deleted "${title}"`);
  };

  const stats = [
    {
      title: 'Total Webinars',
      value: mockWebinars.length,
      icon: Video,
      color: 'text-blue-600 bg-blue-100',
    },
    {
      title: 'Total Registrations',
      value: mockWebinars.reduce((acc, w) => acc + w.currentParticipants, 0),
      icon: Users,
      color: 'text-green-600 bg-green-100',
    },
    {
      title: 'Upcoming',
      value: mockWebinars.filter(w => w.status === 'upcoming').length,
      icon: Calendar,
      color: 'text-purple-600 bg-purple-100',
    },
    {
      title: 'Completed',
      value: mockWebinars.filter(w => w.status === 'completed').length,
      icon: FileText,
      color: 'text-gray-600 bg-gray-100',
    },
  ];

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">Manage webinars, registrations, and resources</p>
          </div>
          <Button onClick={() => setShowCreateForm(!showCreateForm)}>
            <Plus className="mr-2 h-4 w-4" />
            Create Webinar
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                    <p className="text-3xl font-bold">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${stat.color}`}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Create Webinar Form */}
        {showCreateForm && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Create New Webinar</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateWebinar} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Webinar Title</Label>
                    <Input
                      id="title"
                      value={newWebinar.title}
                      onChange={(e) => setNewWebinar({ ...newWebinar, title: e.target.value })}
                      placeholder="e.g., Introduction to React"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="instructor">Instructor Name</Label>
                    <Input
                      id="instructor"
                      value={newWebinar.instructor}
                      onChange={(e) => setNewWebinar({ ...newWebinar, instructor: e.target.value })}
                      placeholder="e.g., John Smith"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newWebinar.description}
                    onChange={(e) => setNewWebinar({ ...newWebinar, description: e.target.value })}
                    placeholder="Describe what participants will learn..."
                    rows={4}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={newWebinar.date}
                      onChange={(e) => setNewWebinar({ ...newWebinar, date: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="time">Time</Label>
                    <Input
                      id="time"
                      type="time"
                      value={newWebinar.time}
                      onChange={(e) => setNewWebinar({ ...newWebinar, time: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="duration">Duration</Label>
                    <Input
                      id="duration"
                      value={newWebinar.duration}
                      onChange={(e) => setNewWebinar({ ...newWebinar, duration: e.target.value })}
                      placeholder="e.g., 2 hours"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select 
                      value={newWebinar.category} 
                      onValueChange={(value) => setNewWebinar({ ...newWebinar, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Programming">Programming</SelectItem>
                        <SelectItem value="Design">Design</SelectItem>
                        <SelectItem value="Marketing">Marketing</SelectItem>
                        <SelectItem value="Business">Business</SelectItem>
                        <SelectItem value="Data Science">Data Science</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="maxParticipants">Max Participants</Label>
                    <Input
                      id="maxParticipants"
                      type="number"
                      value={newWebinar.maxParticipants}
                      onChange={(e) => setNewWebinar({ ...newWebinar, maxParticipants: parseInt(e.target.value) })}
                      min={1}
                      required
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button type="submit">Create Webinar</Button>
                  <Button type="button" variant="outline" onClick={() => setShowCreateForm(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Tabs */}
        <Tabs defaultValue="webinars" className="space-y-6">
          <TabsList>
            <TabsTrigger value="webinars">Manage Webinars</TabsTrigger>
            <TabsTrigger value="registrations">Registrations</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="webinars">
            <Card>
              <CardHeader>
                <CardTitle>All Webinars</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Instructor</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Participants</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockWebinars.map((webinar) => (
                      <TableRow key={webinar.id}>
                        <TableCell className="font-medium">{webinar.title}</TableCell>
                        <TableCell>{webinar.instructor}</TableCell>
                        <TableCell>
                          {new Date(webinar.date).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              webinar.status === 'live'
                                ? 'destructive'
                                : webinar.status === 'upcoming'
                                ? 'default'
                                : 'secondary'
                            }
                          >
                            {webinar.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {webinar.currentParticipants} / {webinar.maxParticipants}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="ghost">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDeleteWebinar(webinar.title)}
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="registrations">
            <Card>
              <CardHeader>
                <CardTitle>Recent Registrations</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Webinar</TableHead>
                      <TableHead>Registered On</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockRegistrations.map((registration) => {
                      const webinar = mockWebinars.find(w => w.id === registration.webinarId);
                      return (
                        <TableRow key={registration.id}>
                          <TableCell className="font-medium">{registration.userName}</TableCell>
                          <TableCell>{registration.userEmail}</TableCell>
                          <TableCell>{webinar?.title}</TableCell>
                          <TableCell>
                            {new Date(registration.registeredAt).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="resources">
            <Card>
              <CardHeader>
                <CardTitle>Upload Resources</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="webinar-select">Select Webinar</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a webinar" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockWebinars.map((webinar) => (
                          <SelectItem key={webinar.id} value={webinar.id}>
                            {webinar.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="recording">Recording URL</Label>
                    <Input id="recording" placeholder="https://..." />
                  </div>

                  <div>
                    <Label htmlFor="materials">Upload Materials</Label>
                    <Input id="materials" type="file" multiple />
                    <p className="text-sm text-gray-500 mt-1">
                      Upload PDFs, slides, or other materials
                    </p>
                  </div>

                  <Button>Upload Resources</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
