import { mockWebinars } from '../lib/mockData';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Calendar, Clock, Download, Video } from 'lucide-react';
import { Link } from 'react-router';

export default function Dashboard() {
  // Mock registered webinars (in a real app, this would come from user's registrations)
  const registeredWebinars = mockWebinars.filter(w => 
    w.id === '1' || w.id === '2' || w.id === '4'
  );

  const upcomingWebinars = registeredWebinars.filter(w => w.status === 'upcoming');
  const liveWebinars = registeredWebinars.filter(w => w.status === 'live');
  const completedWebinars = mockWebinars.filter(w => w.status === 'completed' && w.resources);

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">My Dashboard</h1>
          <p className="text-gray-600">Manage your webinar registrations and access resources</p>
        </div>

        {/* Live Webinars */}
        {liveWebinars.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">🔴 Live Now</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {liveWebinars.map(webinar => (
                <Card key={webinar.id} className="border-red-200 bg-red-50">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <Badge className="bg-red-500 text-white mb-2">LIVE</Badge>
                        <CardTitle className="mb-2">{webinar.title}</CardTitle>
                        <p className="text-sm text-gray-600">by {webinar.instructor}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span>{webinar.time} • {webinar.duration}</span>
                      </div>
                      <Link to={`/webinar/${webinar.id}`}>
                        <Button className="w-full" size="lg">
                          <Video className="mr-2 h-4 w-4" />
                          Join Now
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Upcoming Webinars */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Upcoming Webinars</h2>
          {upcomingWebinars.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {upcomingWebinars.map(webinar => (
                <Card key={webinar.id}>
                  <CardHeader>
                    <Badge variant="outline" className="mb-2 w-fit">{webinar.category}</Badge>
                    <CardTitle className="mb-2">{webinar.title}</CardTitle>
                    <p className="text-sm text-gray-600">by {webinar.instructor}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span>{new Date(webinar.date).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric',
                          year: 'numeric'
                        })}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span>{webinar.time} • {webinar.duration}</span>
                      </div>
                      <Link to={`/webinar/${webinar.id}`}>
                        <Button variant="outline" className="w-full">
                          View Details
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">You have no upcoming webinars registered</p>
                <Link to="/webinars">
                  <Button>Browse Webinars</Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Past Webinars & Resources */}
        <div>
          <h2 className="text-2xl font-semibold mb-4">Past Webinars & Resources</h2>
          {completedWebinars.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-6">
              {completedWebinars.map(webinar => (
                <Card key={webinar.id}>
                  <CardHeader>
                    <Badge variant="secondary" className="mb-2 w-fit">{webinar.category}</Badge>
                    <CardTitle className="mb-2">{webinar.title}</CardTitle>
                    <p className="text-sm text-gray-600">by {webinar.instructor}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Calendar className="h-4 w-4" />
                        <span>Completed on {new Date(webinar.date).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric',
                          year: 'numeric'
                        })}</span>
                      </div>
                      {webinar.resources && (
                        <div className="space-y-2">
                          {webinar.resources.recording && (
                            <Button variant="outline" className="w-full justify-start" size="sm">
                              <Video className="mr-2 h-4 w-4" />
                              Watch Recording
                            </Button>
                          )}
                          {webinar.resources.materials && webinar.resources.materials.length > 0 && (
                            <Button variant="outline" className="w-full justify-start" size="sm">
                              <Download className="mr-2 h-4 w-4" />
                              Download Materials ({webinar.resources.materials.length})
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Video className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No past webinars to display</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
