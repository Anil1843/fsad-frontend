import { Outlet } from 'react-router';
import { Navigation } from '../components/Navigation';

export default function Root() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <Outlet />
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-semibold text-lg mb-4">EduWebinar</h3>
              <p className="text-gray-400 text-sm">
                Empowering learners worldwide with expert-led educational webinars and workshops.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Browse Webinars</li>
                <li>Upcoming Events</li>
                <li>Past Recordings</li>
                <li>Instructors</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>About Us</li>
                <li>Contact</li>
                <li>Careers</li>
                <li>Blog</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Help Center</li>
                <li>Terms of Service</li>
                <li>Privacy Policy</li>
                <li>FAQ</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2026 EduWebinar. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
