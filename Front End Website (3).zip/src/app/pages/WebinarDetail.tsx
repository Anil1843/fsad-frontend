import { useParams, Link } from 'react-router';
import { mockWebinars } from '../lib/mockData';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Calendar, Clock, Download, Users, Video } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

export default function WebinarDetail() {
  const { id } = useParams();
  const webinar = mockWebinars.find(w => w.id === id);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [isRegistered, setIsRegistered] = useState(false);

  if (!webinar) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Webinar Not Found</h1>
          <Link to="/webinars">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Webinars
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    setIsRegistered(true);
    toast.success('Successfully registered for the webinar!', {
      description: 'You will receive a confirmation email shortly.',
    });
  };

  const handleJoinLive = () => {
    toast.info('Launching webinar...', {
      description: 'Opening the live session in a new window.',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live':
        return 'bg-red-500 text-white';
      case 'upcoming':
        return 'bg-blue-500 text-white';
      case 'completed':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-gray-300';
    }
  };

  const spotsLeft = webinar.maxParticipants - webinar.currentParticipants;
  const isFull = spotsLeft <= 0;

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <Link to="/webinars" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Webinars
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <img
                src={webinar.imageUrl}
                alt={webinar.title}
                className="w-full h-80 object-cover rounded-lg"
              />
            </div>

            <div className="flex items-center gap-3 mb-4">
              <Badge className={getStatusColor(webinar.status)}>
                {webinar.status === 'live' ? '🔴 LIVE' : webinar.status.toUpperCase()}
              </Badge>
              <Badge variant="outline">{webinar.category}</Badge>
            </div>

            <h1 className="text-4xl font-bold mb-4">{webinar.title}</h1>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="flex items-start gap-3">
                <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-600">Date</p>
                  <p className="font-medium">
                    {new Date(webinar.date).toLocaleDateString('en-US', {
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-gray-500 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-600">Time</p>
                  <p className="font-medium">{webinar.time}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-gray-500 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-600">Duration</p>
                  <p className="font-medium">{webinar.duration}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Users className="h-5 w-5 text-gray-500 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-600">Participants</p>
                  <p className="font-medium">
                    {webinar.currentParticipants}/{webinar.maxParticipants}
                  </p>
                </div>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-semibold mb-3">About This Webinar</h2>
              <p className="text-gray-700 leading-relaxed">{webinar.description}</p>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-semibold mb-3">Instructor</h2>
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-2xl font-bold">
                  {webinar.instructor.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-lg">{webinar.instructor}</p>
                  <p className="text-gray-600 text-sm">Industry Expert</p>
                </div>
              </div>
            </div>

            {webinar.status === 'completed' && webinar.resources && (
              <div>
                <h2 className="text-2xl font-semibold mb-3">Resources</h2>
                <Card>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      {webinar.resources.recording && (
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <div className="flex items-center gap-3">
                            <Video className="h-5 w-5 text-blue-600" />
                            <span className="font-medium">Recording</span>
                          </div>
                          <Button size="sm" variant="outline">
                            <Download className="mr-2 h-4 w-4" />
                            Watch
                          </Button>
                        </div>
                      )}
                      {webinar.resources.materials?.map((material, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <div className="flex items-center gap-3">
                            <Download className="h-5 w-5 text-green-600" />
                            <span className="font-medium">{material}</span>
                          </div>
                          <Button size="sm" variant="outline">
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div>
            <Card className="sticky top-24">
              <CardContent className="p-6">
                {webinar.status === 'live' ? (
                  <div>
                    <h3 className="font-semibold text-lg mb-4">🔴 Session is Live!</h3>
                    <Button className="w-full mb-3" size="lg" onClick={handleJoinLive}>
                      <Video className="mr-2 h-5 w-5" />
                      Join Live Session
                    </Button>
                    <p className="text-sm text-gray-600 text-center">
                      {webinar.currentParticipants} participants currently watching
                    </p>
                  </div>
                ) : webinar.status === 'completed' ? (
                  <div>
                    <h3 className="font-semibold text-lg mb-4">This webinar has ended</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Access the recording and materials in the Resources section below.
                    </p>
                    {webinar.resources?.recording && (
                      <Button className="w-full" variant="outline">
                        <Video className="mr-2 h-4 w-4" />
                        Watch Recording
                      </Button>
                    )}
                  </div>
                ) : isRegistered ? (
                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">You're Registered!</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      We've sent a confirmation email with the webinar link and calendar invite.
                    </p>
                    <Link to="/dashboard">
                      <Button variant="outline" className="w-full">
                        View My Dashboard
                      </Button>
                    </Link>
                  </div>
                ) : isFull ? (
                  <div>
                    <h3 className="font-semibold text-lg mb-4">Fully Booked</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      This webinar has reached maximum capacity. Check back for future sessions!
                    </p>
                    <Button className="w-full" variant="outline" disabled>
                      Registration Closed
                    </Button>
                  </div>
                ) : (
                  <div>
                    <h3 className="font-semibold text-lg mb-4">Register for this Webinar</h3>
                    
                    {spotsLeft <= 10 && (
                      <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-4">
                        <p className="text-sm text-orange-800">
                          ⚠️ Only {spotsLeft} spot{spotsLeft !== 1 ? 's' : ''} left!
                        </p>
                      </div>
                    )}

                    <form onSubmit={handleRegistration} className="space-y-4">
                      <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="John Doe"
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="email">Email Address</Label>
                        <Input
                          id="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="john@example.com"
                          required
                        />
                      </div>

                      <Button type="submit" className="w-full" size="lg">
                        Register Now
                      </Button>
                    </form>

                    <p className="text-xs text-gray-500 mt-4 text-center">
                      By registering, you agree to receive email notifications about this webinar.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
