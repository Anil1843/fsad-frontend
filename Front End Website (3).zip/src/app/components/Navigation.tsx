import { Link, useLocation } from 'react-router';
import { Calendar, Home, LayoutDashboard, User, Video } from 'lucide-react';
import { Button } from './ui/button';

export function Navigation() {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <header className="border-b bg-white sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <nav className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Video className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-semibold">EduWebinar</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-6">
            <Link 
              to="/" 
              className={`flex items-center gap-2 transition-colors ${
                isActive('/') ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Home className="h-4 w-4" />
              Home
            </Link>
            <Link 
              to="/webinars" 
              className={`flex items-center gap-2 transition-colors ${
                isActive('/webinars') ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Calendar className="h-4 w-4" />
              Browse Webinars
            </Link>
            <Link 
              to="/dashboard" 
              className={`flex items-center gap-2 transition-colors ${
                isActive('/dashboard') ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <User className="h-4 w-4" />
              My Dashboard
            </Link>
            <Link 
              to="/admin" 
              className={`flex items-center gap-2 transition-colors ${
                isActive('/admin') ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <LayoutDashboard className="h-4 w-4" />
              Admin
            </Link>
          </div>
          
          <div className="flex items-center gap-3">
            <Link to="/signin">
              <Button variant="ghost">Sign In</Button>
            </Link>
            <Link to="/signup">
              <Button>Sign Up</Button>
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}