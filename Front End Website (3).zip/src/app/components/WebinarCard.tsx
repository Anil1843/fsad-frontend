import { Link } from 'react-router';
import { Webinar } from '../lib/mockData';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter } from './ui/card';
import { Calendar, Clock, Users } from 'lucide-react';

interface WebinarCardProps {
  webinar: Webinar;
}

export function WebinarCard({ webinar }: WebinarCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live':
        return 'bg-red-500 text-white';
      case 'upcoming':
        return 'bg-blue-500 text-white';
      case 'completed':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-gray-300';
    }
  };

  const spotsLeft = webinar.maxParticipants - webinar.currentParticipants;
  const isFull = spotsLeft <= 0;

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <img 
          src={webinar.imageUrl} 
          alt={webinar.title}
          className="w-full h-48 object-cover"
        />
        <Badge className={`absolute top-3 right-3 ${getStatusColor(webinar.status)}`}>
          {webinar.status === 'live' ? '🔴 LIVE' : webinar.status.toUpperCase()}
        </Badge>
      </div>
      
      <CardContent className="p-4">
        <Badge variant="outline" className="mb-2">
          {webinar.category}
        </Badge>
        
        <h3 className="font-semibold text-lg mb-2 line-clamp-2">
          {webinar.title}
        </h3>
        
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">
          {webinar.description}
        </p>
        
        <div className="space-y-2 text-sm text-gray-700">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <span>{new Date(webinar.date).toLocaleDateString('en-US', { 
              month: 'short', 
              day: 'numeric', 
              year: 'numeric' 
            })}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-gray-500" />
            <span>{webinar.time} • {webinar.duration}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-gray-500" />
            <span>
              {webinar.currentParticipants} / {webinar.maxParticipants} participants
              {!isFull && spotsLeft <= 10 && (
                <span className="text-orange-600 ml-1">
                  ({spotsLeft} spots left!)
                </span>
              )}
            </span>
          </div>
        </div>
        
        <p className="text-sm text-gray-600 mt-3">
          Instructor: <span className="font-medium">{webinar.instructor}</span>
        </p>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Link to={`/webinar/${webinar.id}`} className="w-full">
          <Button className="w-full" disabled={isFull && webinar.status === 'upcoming'}>
            {webinar.status === 'live' ? 'Join Now' : 
             webinar.status === 'completed' ? 'View Resources' :
             isFull ? 'Fully Booked' : 'Register Now'}
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
