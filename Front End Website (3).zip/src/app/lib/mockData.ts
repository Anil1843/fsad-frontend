export type WebinarStatus = 'upcoming' | 'live' | 'completed';

export interface Webinar {
  id: string;
  title: string;
  description: string;
  instructor: string;
  date: string;
  time: string;
  duration: string;
  status: WebinarStatus;
  category: string;
  imageUrl: string;
  maxParticipants: number;
  currentParticipants: number;
  resources?: {
    recording?: string;
    materials?: string[];
  };
}

export interface Registration {
  id: string;
  webinarId: string;
  userName: string;
  userEmail: string;
  registeredAt: string;
}

export const mockWebinars: Webinar[] = [
  {
    id: '1',
    title: 'Introduction to Web Development',
    description: 'Learn the fundamentals of HTML, CSS, and JavaScript. Perfect for beginners who want to start their journey in web development.',
    instructor: 'Sarah Johnson',
    date: '2026-04-15',
    time: '10:00 AM',
    duration: '2 hours',
    status: 'upcoming',
    category: 'Programming',
    imageUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800',
    maxParticipants: 100,
    currentParticipants: 45,
  },
  {
    id: '2',
    title: 'Advanced React Patterns',
    description: 'Deep dive into advanced React concepts including custom hooks, context patterns, and performance optimization techniques.',
    instructor: 'Michael Chen',
    date: '2026-04-10',
    time: '2:00 PM',
    duration: '3 hours',
    status: 'live',
    category: 'Programming',
    imageUrl: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800',
    maxParticipants: 50,
    currentParticipants: 50,
  },
  {
    id: '3',
    title: 'Digital Marketing Essentials',
    description: 'Master the core principles of digital marketing, SEO, social media strategies, and analytics to grow your business online.',
    instructor: 'Emily Rodriguez',
    date: '2026-03-28',
    time: '11:00 AM',
    duration: '2.5 hours',
    status: 'completed',
    category: 'Marketing',
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800',
    maxParticipants: 80,
    currentParticipants: 72,
    resources: {
      recording: 'https://example.com/recording-3',
      materials: ['slides.pdf', 'resources.pdf'],
    },
  },
  {
    id: '4',
    title: 'UI/UX Design Fundamentals',
    description: 'Explore the principles of user interface and user experience design. Learn to create intuitive and beautiful digital products.',
    instructor: 'David Kim',
    date: '2026-04-20',
    time: '1:00 PM',
    duration: '2 hours',
    status: 'upcoming',
    category: 'Design',
    imageUrl: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800',
    maxParticipants: 60,
    currentParticipants: 38,
  },
  {
    id: '5',
    title: 'Data Science with Python',
    description: 'Introduction to data analysis, visualization, and machine learning using Python and popular libraries like pandas and scikit-learn.',
    instructor: 'Dr. Lisa Wang',
    date: '2026-04-25',
    time: '9:00 AM',
    duration: '4 hours',
    status: 'upcoming',
    category: 'Data Science',
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800',
    maxParticipants: 75,
    currentParticipants: 52,
  },
  {
    id: '6',
    title: 'Project Management Best Practices',
    description: 'Learn agile methodologies, team collaboration techniques, and project planning strategies for successful project delivery.',
    instructor: 'James Wilson',
    date: '2026-04-01',
    time: '3:00 PM',
    duration: '2 hours',
    status: 'completed',
    category: 'Business',
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800',
    maxParticipants: 100,
    currentParticipants: 95,
    resources: {
      recording: 'https://example.com/recording-6',
      materials: ['templates.zip', 'checklist.pdf'],
    },
  },
];

export const mockRegistrations: Registration[] = [
  {
    id: 'r1',
    webinarId: '1',
    userName: 'John Doe',
    userEmail: 'john@example.com',
    registeredAt: '2026-04-01T10:00:00Z',
  },
  {
    id: 'r2',
    webinarId: '2',
    userName: 'Jane Smith',
    userEmail: 'jane@example.com',
    registeredAt: '2026-04-02T14:30:00Z',
  },
];
