import { createBrowserRouter } from 'react-router';
import Root from './pages/Root';
import Home from './pages/Home';
import Webinars from './pages/Webinars';
import WebinarDetail from './pages/WebinarDetail';
import Dashboard from './pages/Dashboard';
import Admin from './pages/Admin';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';
import NotFound from './pages/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: 'webinars', Component: Webinars },
      { path: 'webinar/:id', Component: WebinarDetail },
      { path: 'dashboard', Component: Dashboard },
      { path: 'admin', Component: Admin },
      { path: '*', Component: NotFound },
    ],
  },
  {
    path: '/signin',
    Component: SignIn,
  },
  {
    path: '/signup',
    Component: SignUp,
  },
]);